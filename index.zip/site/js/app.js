/* ===== EDIT HERE: brand settings ===== */
const CONFIG={
 brand:"AK Alishba Khalil",
 announcement:"Complimentary gift wrapping on every order  |  Nationwide delivery across Pakistan",
 whatsapp:"923000000000", /* country code + number, no + or spaces */
 phone:"+92 300 0000000", email:"hello@yourdomain.com", address:"Your boutique address, Karachi, Pakistan", hours:"Mon to Sat, 11am to 8pm",
 social:{Instagram:"https://instagram.com/",Facebook:"https://facebook.com/",TikTok:"https://tiktok.com/",YouTube:"https://youtube.com/",Threads:"https://threads.net/"},
 shipping:0, /* flat delivery fee in PKR; 0 = shown as 'to be confirmed' */
 sampleNotice:true
};
/* ===== EDIT HERE: product catalogue (SAMPLE items and prices; replace with your real catalogue) =====
 cat: new | luxury | unstitched | two | three | abaya ; flags: best, trend, isNew ; img: optional photo URL (data URI or hosted) */
const COLORS={Ivory:"#F4EBDD",Champagne:"#E5D2B5",Black:"#171513",Gold:"#B08A45",Blush:"#E3BFB3",Emerald:"#1F5B4A",Burgundy:"#6B1F2B",Navy:"#1E2A4A",Sage:"#9DAA8C"};
const P=[
{id:"s1",name:"Zarina Embroidered Luxury Suit",cat:"luxury",price:45000,colors:["Champagne","Emerald","Black"],sizes:["S","M","L"],isNew:1,best:1,fabric:"Raw silk shirt, organza dupatta, raw silk trouser",desc:"Hand-finished neckline embroidery with antique gold zari detailing.",shape:"suit"},
{id:"s2",name:"Noor Formal Three-Piece",cat:"three",price:38000,colors:["Blush","Burgundy"],sizes:["S","M","L","XL"],trend:1,fabric:"Chiffon, jamawar trouser, net dupatta",desc:"Soft drape with scalloped borders and tonal embroidery.",shape:"suit"},
{id:"s3",name:"Mehr Unstitched Collection",cat:"unstitched",price:22000,colors:["Sage","Ivory","Gold"],sizes:[],isNew:1,fabric:"Lawn shirt, embroidered chiffon dupatta, cambric trouser",desc:"Three-piece unstitched fabric, ready to tailor to your measurements.",shape:"fabric"},
{id:"s4",name:"Aiza Two-Piece Co-ord",cat:"two",price:18500,colors:["Ivory","Navy"],sizes:["S","M","L"],best:1,fabric:"Cotton net shirt, straight trouser",desc:"Everyday elegance with fine thread-work on the hem.",shape:"suit"},
{id:"s5",name:"Mahnoor Bridal Edit Gown",cat:"luxury",price:85000,colors:["Gold","Burgundy"],sizes:["S","M","L"],trend:1,fabric:"Tissue silk, hand embellished",desc:"Flared silhouette with a sheer cape sleeve and gold work.",shape:"gown"},
{id:"s6",name:"Sahar Classic Abaya",cat:"abaya",price:16000,colors:["Black","Navy"],sizes:["52","54","56"],isNew:1,best:1,fabric:"Nida crepe with gold piping",desc:"Open-front abaya with a soft fall and tonal detailing.",shape:"abaya"},
{id:"s7",name:"Layla Embroidered Abaya",cat:"abaya",price:24000,colors:["Black","Emerald"],sizes:["52","54","56"],trend:1,fabric:"Premium crepe, embroidered cuffs",desc:"Statement cuffs with fine metallic embroidery.",shape:"abaya"},
{id:"s8",name:"Rania Unstitched Silk Set",cat:"unstitched",price:29000,colors:["Champagne","Blush"],sizes:[],fabric:"Raw silk shirt, organza dupatta, trouser fabric",desc:"Heavy neckline panel and border for custom stitching.",shape:"fabric"},
{id:"s9",name:"Dua Three-Piece Festive",cat:"three",price:32000,colors:["Emerald","Gold","Ivory"],sizes:["S","M","L"],best:1,fabric:"Jacquard shirt, chiffon dupatta, silk trouser",desc:"Rich texture with a lightly embellished neckline.",shape:"suit"},
{id:"s10",name:"Hoor Two-Piece Luxe",cat:"two",price:21000,colors:["Navy","Blush"],sizes:["S","M","L","XL"],isNew:1,fabric:"Silk blend shirt, tailored trouser",desc:"Clean lines with a subtle gold edge.",shape:"suit"}
];
const CATS={new:"New Arrivals",luxury:"Luxury Pakistani Suits",unstitched:"Unstitched Collections",two:"Two-Piece Suits",three:"Three-Piece Suits",abaya:"Elegant Abayas",best:"Best Sellers",trend:"Trending Collections"};
/* ===== end of editable area ===== */
const $=s=>document.querySelector(s),pk=n=>"PKR "+n.toLocaleString("en-PK");
let cart=[];try{cart=JSON.parse(localStorage.getItem("akcart")||"[]")}catch(e){}
const save=()=>{try{localStorage.setItem("akcart",JSON.stringify(cart))}catch(e){}$("#cc").textContent=cart.reduce((a,c)=>a+c.q,0)};
const toast=m=>{const t=$("#ts");t.textContent=m;t.classList.add("on");setTimeout(()=>t.classList.remove("on"),1800)};
const hex=c=>COLORS[c]||"#ccc";
function art(p,v){ /* editable SVG placeholder: replace with p.img photo */
 if(p.img&&v==0)return `<img src="${p.img}" alt="${p.name}" style="width:100%;display:block">`;
 const c=hex(p.colors[0]),g="#B08A45",o=v==1?`<rect x="150" y="150" width="100" height="90" fill="none" stroke="${g}" stroke-width="1.5" stroke-dasharray="3 3"/><circle cx="200" cy="195" r="26" fill="none" stroke="${g}"/>`:"";
 let b;
 if(v==2)b=`<defs><pattern id="f${p.id}" width="14" height="14" patternUnits="userSpaceOnUse" patternTransform="rotate(30)"><rect width="14" height="14" fill="${c}"/><path d="M0 7h14" stroke="${g}" stroke-width=".8"/></pattern></defs><rect x="40" y="60" width="320" height="380" fill="url(#f${p.id})" stroke="${g}"/>`;
 else if(p.shape=="abaya")b=`<path d="M170 80q30-30 60 0l30 40 20 330H120l20-330z" fill="${c}"/><path d="M200 90v360" stroke="${g}" stroke-width="2"/>${o}`;
 else if(p.shape=="gown")b=`<path d="M175 80q25-22 50 0l12 100 90 280H73l90-280z" fill="${c}"/><path d="M165 185h70" stroke="${g}" stroke-width="3"/>${o}`;
 else if(p.shape=="fabric")b=`<rect x="90" y="90" width="220" height="340" fill="${c}" stroke="${g}"/><rect x="104" y="104" width="192" height="312" fill="none" stroke="${g}" stroke-dasharray="4 4"/><path d="M104 380q96-50 192 0" stroke="${g}" fill="none" stroke-width="2"/>${o}`;
 else b=`<path d="M165 80q35-30 70 0l45 60-20 30-25-15v140l30 150H135l30-150V155l-25 15-20-30z" fill="${c}"/><path d="M175 85q25 25 50 0" stroke="${g}" fill="none" stroke-width="2"/>${o}`;
 return `<svg viewBox="0 0 400 500" role="img" aria-label="${p.name}"><rect width="400" height="500" fill="#F3E6D3"/>${b}</svg>`}
const sw=p=>`<div class="sw">${p.colors.map(c=>`<i title="${c}" style="background:${hex(c)}"></i>`).join("")}</div>`;
const card=p=>`<article class="card"><a class="im" href="#p-${p.id}">${art(p,0)}${p.isNew?'<span class="tag">NEW</span>':p.best?'<span class="tag">BEST SELLER</span>':""}</a><div class="in"><h3>${p.name}</h3><div class="price">${pk(p.price)}</div>${sw(p)}<div class="d">${p.desc}</div><button class="btn" onclick="add('${p.id}')">Add to Cart</button></div></article>`;
function add(id,color,size){const p=P.find(x=>x.id==id);color=color||p.colors[0];size=size||(p.sizes[0]||"-");const k=id+color+size,e=cart.find(c=>c.k==k);e?e.q++:cart.push({k,id,color,size,q:1});save();toast("Added to cart")}
const match=(p,c)=>c=="all"||p.cat==c||(c=="new"&&p.isNew)||(c=="best"&&p.best)||(c=="trend"&&p.trend);
let F={c:"all",q:"",col:"",sort:""};
function list(){let l=P.filter(p=>match(p,F.c)&&p.name.toLowerCase().includes(F.q.toLowerCase())&&(!F.col||p.colors.includes(F.col)));if(F.sort=="a")l.sort((a,b)=>a.price-b.price);if(F.sort=="d")l.sort((a,b)=>b.price-a.price);
 $("#res").innerHTML=l.length?l.map(card).join(""):'<p class="empty">No products match. Try another filter.</p>'}
function shop(title,cats,sub){F={c:cats[0],q:"",col:"",sort:""};
 return `<section><div class="wrap"><div class="ttl"><h2>${title}</h2><span class="orn"></span>${sub?`<p>${sub}</p>`:""}${CONFIG.sampleNotice?'<p class="note">Sample catalogue: products and prices are placeholders to be replaced.</p>':""}</div>
 ${cats.length>1?`<div class="chips">${cats.map(c=>`<button class="chip ${c==F.c?"on":""}" data-c="${c}">${c=="all"?"All":CATS[c]}</button>`).join("")}</div>`:""}
 <div class="tools"><input id="sq" type="search" placeholder="Search products" aria-label="Search"><select id="sc" aria-label="Colour"><option value="">All colours</option>${Object.keys(COLORS).map(c=>`<option>${c}</option>`).join("")}</select><select id="so" aria-label="Sort"><option value="">Sort: Featured</option><option value="a">Price: low to high</option><option value="d">Price: high to low</option></select></div>
 <div class="grid" id="res"></div></div></section>`}
function bindShop(){list();document.querySelectorAll(".chip").forEach(b=>b.onclick=()=>{F.c=b.dataset.c;document.querySelectorAll(".chip").forEach(x=>x.classList.toggle("on",x==b));list()});
 $("#sq").oninput=e=>{F.q=e.target.value;list()};$("#sc").onchange=e=>{F.col=e.target.value;list()};$("#so").onchange=e=>{F.sort=e.target.value;list()}}
function home(){return `<div class="hero"><div class="wrap"><div><h1>Elegance in Every Thread.</h1><p>Because Every Woman Deserves Style.</p><div class="bt"><a class="btn" href="#shop">Shop Now</a><a class="btn o" href="#suits">Explore Collection</a></div></div><div class="frame"><img src="assets/logo.jpg" alt="AK Alishba Khalil brand emblem"></div></div></div>
<section><div class="wrap"><div class="ttl"><h2>Shop by Collection</h2><span class="orn"></span></div><div class="cats">${Object.keys(CATS).map(k=>`<a class="cat" href="#shop-${k}">${CATS[k]}</a>`).join("")}</div></div></section>
<section style="background:var(--ch)"><div class="wrap"><div class="ttl"><h2>New Arrivals</h2><span class="orn"></span></div><div class="grid">${P.filter(p=>p.isNew).slice(0,4).map(card).join("")}</div></div></section>
<section><div class="wrap"><div class="ttl"><h2>Best Sellers</h2><span class="orn"></span></div><div class="grid">${P.filter(p=>p.best).slice(0,4).map(card).join("")}</div></div></section>`}
function product(id){const p=P.find(x=>x.id==id);if(!p)return '<p class="empty">Product not found. <a href="#shop">Back to shop</a></p>';let col=p.colors[0],sz=p.sizes[0]||"-";
 return `<section><div class="wrap"><p class="note"><a href="#shop">Shop</a> / ${CATS[p.cat]||""}</p><div class="pd"><div class="gal"><div class="main" id="gm">${art(p,0)}</div><div class="thumbs">${[0,1,2].map(i=>`<button class="${i?"":"on"}" data-v="${i}" aria-label="View ${i+1}">${art(p,i)}</button>`).join("")}</div></div>
 <div><h1>${p.name}</h1><div class="price">${pk(p.price)}</div><p>${p.desc}</p>
 <div class="opt"><b>COLOUR: <span id="cn">${col}</span></b><div class="pick" id="pc">${p.colors.map((c,i)=>`<button class="${i?"":"on"}" data-c="${c}"><span class="cl"><i style="background:${hex(c)}"></i>${c}</span></button>`).join("")}</div></div>
 ${p.sizes.length?`<div class="opt"><b>SIZE</b><div class="pick" id="ps">${p.sizes.map((s,i)=>`<button class="${i?"":"on"}" data-s="${s}">${s}</button>`).join("")}</div></div>`:'<div class="opt"><b>Unstitched: tailor to your own measurements</b></div>'}
 <div style="display:flex;gap:10px;flex-wrap:wrap"><button class="btn" id="pa">Add to Cart</button><a class="btn wa" id="pw" target="_blank" rel="noopener">Order on WhatsApp</a></div>
 <div class="fab"><b>Fabric:</b> ${p.fabric}<br><b>Details:</b> ${p.desc}</div>${CONFIG.sampleNotice?'<p class="note">Sample product. Photos, price and availability are placeholders until the real catalogue is added.</p>':""}</div></div></div></section>`}
function bindProduct(id){const p=P.find(x=>x.id==id);if(!p)return;let col=p.colors[0],sz=p.sizes[0]||"-";
 const wa=()=>$("#pw").href=`https://wa.me/${CONFIG.whatsapp}?text=`+encodeURIComponent(`Hello ${CONFIG.brand}, I would like to order: ${p.name}, Colour: ${col}, Size: ${sz}, ${pk(p.price)}`);wa();
 document.querySelectorAll(".thumbs button").forEach(b=>b.onclick=()=>{$("#gm").innerHTML=art(p,+b.dataset.v);document.querySelectorAll(".thumbs button").forEach(x=>x.classList.toggle("on",x==b))});
 document.querySelectorAll("#pc button").forEach(b=>b.onclick=()=>{col=b.dataset.c;$("#cn").textContent=col;document.querySelectorAll("#pc button").forEach(x=>x.classList.toggle("on",x==b));wa()});
 document.querySelectorAll("#ps button").forEach(b=>b.onclick=()=>{sz=b.dataset.s;document.querySelectorAll("#ps button").forEach(x=>x.classList.toggle("on",x==b));wa()});
 $("#pa").onclick=()=>add(id,col,sz)}
const rows=()=>cart.map(c=>({...c,p:P.find(x=>x.id==c.id)})).filter(r=>r.p);
const sub=()=>rows().reduce((a,r)=>a+r.p.price*r.q,0);
function cartPage(){const r=rows();if(!r.length)return '<section><div class="wrap empty"><h2>Your cart is empty</h2><p style="margin:12px 0 20px">Discover the latest collections.</p><a class="btn" href="#shop">Shop Now</a></div></section>';
 return `<section><div class="wrap"><div class="ttl"><h2>Shopping Cart</h2><span class="orn"></span></div><div class="two"><div style="overflow-x:auto"><table>${r.map(x=>`<tr><td><b>${x.p.name}</b><br><small>${x.color}${x.size!="-"?", size "+x.size:""}</small></td><td><span class="qty"><button onclick="qt('${x.k}',-1)" aria-label="Less">-</button><span>${x.q}</span><button onclick="qt('${x.k}',1)" aria-label="More">+</button></span></td><td>${pk(x.p.price*x.q)}</td><td><button class="chip" onclick="qt('${x.k}',-99)">Remove</button></td></tr>`).join("")}</table></div>
 <div class="box sum"><h3>Order summary</h3><div><span>Subtotal</span><span>${pk(sub())}</span></div><div><span>Delivery</span><span>${CONFIG.shipping?pk(CONFIG.shipping):"Confirmed at checkout"}</span></div><div class="t"><span>Total</span><span>${pk(sub()+CONFIG.shipping)}</span></div><a class="btn" style="display:block;text-align:center;margin-top:14px" href="#checkout">Proceed to Checkout</a></div></div></div></section>`}
function qt(k,d){const c=cart.find(x=>x.k==k);if(!c)return;c.q+=d;if(c.q<1)cart=cart.filter(x=>x.k!=k);save();route()}
function checkout(){const r=rows();if(!r.length)return cartPage();
 return `<section><div class="wrap"><div class="ttl"><h2>Checkout</h2><span class="orn"></span></div><div class="two"><form class="box" id="cf"><h3>Delivery details</h3>
 <label>Full name<input name="n" required autocomplete="name"></label><label>Phone / WhatsApp<input name="t" required type="tel" autocomplete="tel"></label><label>Email (optional)<input name="e" type="email"></label><label>Full address<textarea name="a" rows="3" required></textarea></label><label>City<input name="c" required></label>
 <label>Payment method<select name="m"><option>Cash on delivery</option><option>Bank transfer (details sent on WhatsApp)</option><option>Easypaisa / JazzCash (details sent on WhatsApp)</option></select></label>
 <button class="btn wa" style="width:100%;margin-top:18px">Place Order via WhatsApp</button><p class="note">No card details are collected on this page. Orders are confirmed with you on WhatsApp. Online card payments can be added through a certified payment gateway (see publishing guide).</p></form>
 <div class="box sum"><h3>Your order</h3>${r.map(x=>`<div><span>${x.p.name} x${x.q}</span><span>${pk(x.p.price*x.q)}</span></div>`).join("")}<div class="t"><span>Total</span><span>${pk(sub()+CONFIG.shipping)}</span></div></div></div></div></section>`}
function bindCheckout(){const f=$("#cf");if(!f)return;f.onsubmit=e=>{e.preventDefault();const d=new FormData(f),r=rows();
 const m=`New order, ${CONFIG.brand}\n\n`+r.map(x=>`- ${x.p.name} | ${x.color}${x.size!="-"?" | "+x.size:""} | x${x.q} | ${pk(x.p.price*x.q)}`).join("\n")+`\n\nTotal: ${pk(sub()+CONFIG.shipping)}\nName: ${d.get("n")}\nPhone: ${d.get("t")}\nEmail: ${d.get("e")||"-"}\nAddress: ${d.get("a")}, ${d.get("c")}\nPayment: ${d.get("m")}`;
 window.open(`https://wa.me/${CONFIG.whatsapp}?text=`+encodeURIComponent(m),"_blank");cart=[];save();$("#app").innerHTML='<section><div class="wrap empty"><h2>Thank you</h2><p style="margin:12px 0 20px">Your order message is ready in WhatsApp. Send it to confirm your order.</p><a class="btn" href="#home">Continue Shopping</a></div></section>'}}
function about(){return `<section><div class="wrap abt"><div class="frame"><img src="assets/logo.jpg" alt="AK Alishba Khalil"></div><div><h2 style="font-size:clamp(32px,4vw,48px);margin-bottom:16px">About AK Alishba Khalil</h2><p>AK Alishba Khalil is a Pakistani women's wear label created around one belief: every woman deserves style. Each piece is designed with refined embroidery, considered fabrics and a timeless silhouette.</p><p>From luxury suits and unstitched collections to elegant abayas, the collection is made to be worn for years. Replace this text with your own brand story.</p><a class="btn" href="#shop">Explore the Collection</a></div></div></section>`}
function contact(){return `<section><div class="wrap"><div class="ttl"><h2>Contact Us</h2><span class="orn"></span></div><div class="two"><div class="box"><h3>Visit or message us</h3><p style="margin-top:10px">${CONFIG.address}<br>${CONFIG.phone}<br>${CONFIG.email}<br>${CONFIG.hours}</p><p style="margin-top:16px"><a class="btn wa" target="_blank" rel="noopener" href="https://wa.me/${CONFIG.whatsapp}">Chat on WhatsApp</a></p></div>
 <form class="box" id="ctf"><h3>Send a message</h3><label>Name<input name="n" required></label><label>Message<textarea name="m" rows="4" required></textarea></label><button class="btn" style="margin-top:14px">Send via WhatsApp</button></form></div></div></section>`}
function route(){const h=(location.hash||"#home").slice(1),a=$("#app");let x="";
 if(h=="home")x=home();else if(h.startsWith("shop"))x=shop(h=="shop"||h=="shop-all"?"Shop All":CATS[h.slice(5)]||"Shop",h=="shop"?["all",...Object.keys(CATS)]:[h.slice(5)||"all"]);
 else if(h=="new")x=shop("New Arrivals",["new"],"The latest additions to the collection.");
 else if(h=="suits")x=shop("Suits Collection",["luxury","three","two","unstitched"].length?["all","luxury","unstitched","two","three"]:[]);
 else if(h=="abaya")x=shop("Abaya Collection",["abaya"],"Modest, graceful and finished with gold.");
 else if(h.startsWith("p-"))x=product(h.slice(2));else if(h=="cart")x=cartPage();else if(h=="checkout")x=checkout();else if(h=="about")x=about();else if(h=="contact")x=contact();else x=home();
 if(h=="suits"){/* suits excludes abayas */}
 a.innerHTML=x;
 if(h.startsWith("shop")||h=="new"||h=="suits"||h=="abaya"){if(h=="suits")F.c="all";bindShop();if(h=="suits"){const old=match;list=function(){let l=P.filter(p=>p.cat!="abaya"&&match(p,F.c)&&p.name.toLowerCase().includes(F.q.toLowerCase())&&(!F.col||p.colors.includes(F.col)));if(F.sort=="a")l.sort((a,b)=>a.price-b.price);if(F.sort=="d")l.sort((a,b)=>b.price-a.price);$("#res").innerHTML=l.map(card).join("")||'<p class="empty">No products match.</p>'};list()}}
 if(h.startsWith("p-"))bindProduct(h.slice(2));if(h=="checkout")bindCheckout();
 if(h=="contact")$("#ctf").onsubmit=e=>{e.preventDefault();const d=new FormData(e.target);window.open(`https://wa.me/${CONFIG.whatsapp}?text=`+encodeURIComponent(`${d.get("n")}: ${d.get("m")}`),"_blank")};
 document.querySelectorAll("nav a").forEach(l=>l.classList.toggle("on",l.getAttribute("href")=="#"+h));$("#nv").classList.remove("open");scrollTo(0,0);
 document.title=(h=="home"?"":(h.startsWith("p-")?(P.find(p=>p.id==h.slice(2))||{}).name:h[0].toUpperCase()+h.slice(1))+" | ")+"AK Alishba Khalil | Luxury Pakistani Women's Wear"}
const ic={Instagram:'<rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r=".6"/>',Facebook:'<path d="M14 8h3V4h-3a4 4 0 0 0-4 4v3H7v4h3v6h4v-6h3l1-4h-4V8z"/>',TikTok:'<path d="M14 3v11a4 4 0 1 1-4-4M14 3c0 3 2 5 5 5"/>',YouTube:'<rect x="2.5" y="5.5" width="19" height="13" rx="4"/><path d="M10 9.5v5l4.5-2.5z"/>',Threads:'<path d="M17 9c-1-3-5-4-8-1s-2 9 3 9c4 0 5-3 4-5s-5-2-6 0 1 3 3 3 3-2 2-5"/>'};
$("#soc").innerHTML=Object.keys(CONFIG.social).map(k=>`<a href="${CONFIG.social[k]}" target="_blank" rel="noopener" aria-label="${k}"><svg viewBox="0 0 24 24">${ic[k]}</svg></a>`).join("");
$("#ann").textContent=CONFIG.announcement;$("#fwa").href="https://wa.me/"+CONFIG.whatsapp;
$("#fc").innerHTML=`<li>${CONFIG.address}</li><li>${CONFIG.phone}</li><li>${CONFIG.email}</li><li>${CONFIG.hours}</li>`;
$("#cb").onclick=()=>location.hash="cart";$("#bg").onclick=()=>$("#nv").classList.toggle("open");
addEventListener("hashchange",route);save();route();
