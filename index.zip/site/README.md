# AK Alishba Khalil Women's Wear: website

Static site (HTML, CSS, vanilla JavaScript). No build step. Upload THIS folder.

## Edit before going live
- js/app.js  -> CONFIG (WhatsApp number as 923XXXXXXXXX, phone, email, address, social links)
- js/app.js  -> P (product list). Add `img:"assets/products/photo.jpg"` for real photos
- js/app.js  -> set sampleNotice:false when real products and prices are in
- index.html, sitemap.xml, robots.txt -> replace every `yourdomain.com` with your real domain

## Structure
index.html  css/style.css  js/app.js  assets/ (logo, icons, og-image)
404.html  robots.txt  sitemap.xml  site.webmanifest  netlify.toml  vercel.json
